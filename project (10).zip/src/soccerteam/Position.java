package soccerteam;

/**
 * An enum that stores different positions in soccer, goalie, defender, midfielder and forward.
 */
public enum Position {
  GOALIE, DEFENDER, MIDFIELDER, FORWARD
}
